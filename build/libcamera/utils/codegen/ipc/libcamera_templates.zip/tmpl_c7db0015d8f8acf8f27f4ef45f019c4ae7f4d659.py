from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_proxy_worker.cpp.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_proxy_worker_name = resolve('proxy_worker_name')
    l_0_has_namespace = resolve('has_namespace')
    l_0_namespace = resolve('namespace')
    l_0_cmd_enum_name = resolve('cmd_enum_name')
    l_0_interface_main = resolve('interface_main')
    l_0_interface_name = resolve('interface_name')
    l_0_interface_event = resolve('interface_event')
    l_0_proxy_funcs = missing
    try:
        t_1 = environment.filters['cap']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cap' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['is_async']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_async' found.")
    try:
        t_4 = environment.filters['method_param_inputs']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_inputs' found.")
    try:
        t_5 = environment.filters['method_param_outputs']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_outputs' found.")
    try:
        t_6 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_7 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_8 = environment.filters['params_comma_sep']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'params_comma_sep' found.")
    pass
    l_0_proxy_funcs = context.vars['proxy_funcs'] = environment.get_template('proxy_functions.tmpl', 'module_ipa_proxy_worker.cpp.tmpl')._get_default_module(context)
    context.exported_vars.discard('proxy_funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm proxy worker for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#include <algorithm>\n#include <iostream>\n#include <sys/types.h>\n#include <tuple>\n#include <unistd.h>\n\n#include <libcamera/ipa/ipa_interface.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_interface.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_serializer.h>\n#include <libcamera/logging.h>\n\n#include <libcamera/base/event_dispatcher.h>\n#include <libcamera/base/log.h>\n#include <libcamera/base/thread.h>\n#include <libcamera/base/unique_fd.h>\n\n#include "libcamera/internal/camera_sensor.h"\n#include "libcamera/internal/control_serializer.h"\n#include "libcamera/internal/ipa_data_serializer.h"\n#include "libcamera/internal/ipa_module.h"\n#include "libcamera/internal/ipa_proxy.h"\n#include "libcamera/internal/ipc_pipe.h"\n#include "libcamera/internal/ipc_pipe_unixsocket.h"\n#include "libcamera/internal/ipc_unixsocket.h"\n\nusing namespace libcamera;\n\nLOG_DEFINE_CATEGORY('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ')'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in (undefined(name='namespace') if l_0_namespace is missing else l_0_namespace):
            _loop_vars = {}
            pass
            yield 'using namespace '
            yield str(l_1_ns)
            yield ';\n'
        l_1_ns = missing
    yield '\n\nclass '
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield '\n{\npublic:\n\t'
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield '()\n\t\t: ipa_(nullptr),\n\t\t  controlSerializer_(ControlSerializer::Role::Worker),\n\t\t  exit_(false) {}\n\n\t~'
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield '() {}\n\n\tvoid readyRead()\n\t{\n\t\tIPCUnixSocket::Payload _message;\n\t\tint _retRecv = socket_.receive(&_message);\n\t\tif (_retRecv) {\n\t\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t\t<< "Receive message failed: " << _retRecv;\n\t\t\treturn;\n\t\t}\n\n\t\tIPCMessage _ipcMessage(_message);\n\n\t\t'
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield ' _cmd = static_cast<'
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield '>(_ipcMessage.header().cmd);\n\n\t\tswitch (_cmd) {\n\t\tcase '
    yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
    yield '::Exit: {\n\t\t\texit_ = true;\n\t\t\tbreak;\n\t\t}\n\n'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n\t\tcase '
        yield str((undefined(name='cmd_enum_name') if l_0_cmd_enum_name is missing else l_0_cmd_enum_name))
        yield '::'
        yield str(t_1(environment.getattr(l_1_method, 'mojom_name')))
        yield ': {'
        if (environment.getattr(l_1_method, 'mojom_name') == 'configure'):
            pass
            yield '\n\t\t\tcontrolSerializer_.reset();'
        yield '\n\t\t'
        yield str(t_2(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'deserialize_call'), t_4(l_1_method), '_ipcMessage.data()', '_ipcMessage.fds()', False, True, _loop_vars=_loop_vars), 16, True))
        yield '\n'
        for l_2_param in t_5(l_1_method):
            _loop_vars = {}
            pass
            yield '\n\t\t\t'
            yield str(t_7(l_2_param))
            yield ' '
            yield str(environment.getattr(l_2_param, 'mojom_name'))
            yield ';\n'
        l_2_param = missing
        if (t_6(l_1_method) != 'void'):
            pass
            yield '\n\t\t\t'
            yield str(t_6(l_1_method))
            yield ' _callRet ='
        yield 'ipa_->'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '('
        yield str(t_8(environment.getattr(l_1_method, 'parameters')))
        yield str((', ' if t_8(t_5(l_1_method)) else cond_expr_undefined("the inline if-expression on line 96 in 'module_ipa_proxy_worker.cpp.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(t_5(l_1_method), undefined):
            _loop_vars = {}
            pass
            yield '&'
            yield str(environment.getattr(l_2_param, 'mojom_name'))
            yield str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 98 in 'module_ipa_proxy_worker.cpp.tmpl' evaluated to false and no else section was defined.")))
        l_2_loop = l_2_param = missing
        yield ');\n'
        if (not t_3(l_1_method)):
            pass
            yield '\n\t\t\tIPCMessage::Header header = { _ipcMessage.header().cmd, _ipcMessage.header().cookie };\n\t\t\tIPCMessage _response(header);'
            if (t_6(l_1_method) != 'void'):
                pass
                yield '\n\t\t\tstd::vector<uint8_t> _callRetBuf;\n\t\t\tstd::tie(_callRetBuf, std::ignore) =\n\t\t\t\tIPADataSerializer<'
                yield str(t_6(l_1_method))
                yield '>::serialize(_callRet);\n\t\t\t_response.data().insert(_response.data().end(), _callRetBuf.cbegin(), _callRetBuf.cend());'
            yield '\n\t\t'
            yield str(t_2(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'serialize_call'), t_5(l_1_method), '_response.data()', '_response.fds()', _loop_vars=_loop_vars), 16, True))
            yield '\n\t\t\tint _ret = socket_.send(_response.payload());\n\t\t\tif (_ret < 0) {\n\t\t\t\tLOG('
            yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
            yield ', Error)\n\t\t\t\t\t<< "Reply to '
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '() failed: " << _ret;\n\t\t\t}\n\t\t\tLOG('
            yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
            yield ', Debug) << "Done replying to '
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '()";'
        yield '\n\t\t\tbreak;\n\t\t}\n'
    l_1_loop = l_1_method = missing
    yield '\n\t\tdefault:\n\t\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error) << "Unknown command " << _ipcMessage.header().cmd;\n\t\t}\n\t}\n\n\tint init(std::unique_ptr<IPAModule> &ipam, UniqueFD socketfd)\n\t{\n\t\tif (socket_.bind(std::move(socketfd)) < 0) {\n\t\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t\t<< "IPC socket binding failed";\n\t\t\treturn EXIT_FAILURE;\n\t\t}\n\t\tsocket_.readyRead.connect(this, &'
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield '::readyRead);\n\n\t\tipa_ = dynamic_cast<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *>(ipam->createInterface());\n\t\tif (!ipa_) {\n\t\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t\t<< "Failed to create IPA interface instance";\n\t\t\treturn EXIT_FAILURE;\n\t\t}\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n\t\tipa_->'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '.connect(this, &'
        yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
        yield '::'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield ');'
    l_1_method = missing
    yield '\n\t\treturn 0;\n\t}\n\n\tvoid run()\n\t{\n\t\tEventDispatcher *dispatcher = Thread::current()->eventDispatcher();\n\t\twhile (!exit_)\n\t\t\tdispatcher->processEvents();\n\t}\n\n\tvoid cleanup()\n\t{\n\t\tdelete ipa_;\n\t\tsocket_.close();\n\t}\n\nprivate:\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        l_1_proxy_name = resolve('proxy_name')
        l_1_cmd_event_enum_name = resolve('cmd_event_enum_name')
        _loop_vars = {}
        pass
        yield '\n'
        yield str(t_2(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_1_proxy_name is missing else l_1_proxy_name), l_1_method, '', False, _loop_vars=_loop_vars), 8, True))
        yield '\n\t{\n\t\tIPCMessage::Header header = {\n\t\t\tstatic_cast<uint32_t>('
        yield str((undefined(name='cmd_event_enum_name') if l_1_cmd_event_enum_name is missing else l_1_cmd_event_enum_name))
        yield '::'
        yield str(t_1(environment.getattr(l_1_method, 'mojom_name')))
        yield '),\n\t\t\t0\n\t\t};\n\t\tIPCMessage _message(header);\n\n\t\t'
        yield str(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'serialize_call'), t_4(l_1_method), '_message.data()', '_message.fds()', _loop_vars=_loop_vars))
        yield '\n\n\t\tint _ret = socket_.send(_message.payload());\n\t\tif (_ret < 0)\n\t\t\tLOG('
        yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
        yield ', Error)\n\t\t\t\t<< "Sending event '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield '() failed: " << _ret;\n\n\t\tLOG('
        yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
        yield ', Debug) << "'
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield ' done";\n\t}\n'
    l_1_method = l_1_proxy_name = l_1_cmd_event_enum_name = missing
    yield '\n\n\t'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *ipa_;\n\tIPCUnixSocket socket_;\n\n\tControlSerializer controlSerializer_;\n\n\tbool exit_;\n};\n\nint main(int argc, char **argv)\n{\n\t/* Uncomment this for debugging. */\n#if 0\n\tstd::string logPath = "/tmp/libcamera.worker." +\n\t\t\t      std::to_string(getpid()) + ".log";\n\tlogSetFile(logPath.c_str());\n#endif\n\n\tif (argc < 3) {\n\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t<< "Tried to start worker with no args: "\n\t\t\t<< "expected <path to IPA so> <fd to bind unix socket>";\n\t\treturn EXIT_FAILURE;\n\t}\n\n\tUniqueFD fd(std::stoi(argv[2]));\n\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Info)\n\t\t<< "Starting worker for IPA module " << argv[1]\n\t\t<< " with IPC fd = " << fd.get();\n\n\tstd::unique_ptr<IPAModule> ipam = std::make_unique<IPAModule>(argv[1]);\n\tif (!ipam->isValid() || !ipam->load()) {\n\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t<< "IPAModule " << argv[1] << " isn\'t valid";\n\t\treturn EXIT_FAILURE;\n\t}\n\n\t/*\n\t * Shutdown of proxy worker can be pre-empted by events like\n\t * SIGINT/SIGTERM, even before the pipeline handler can request\n\t * shutdown. Hence, assign a new gid to prevent signals on the\n\t * application being delivered to the proxy.\n\t */\n\tif (setpgid(0, 0) < 0) {\n\t\tint err = errno;\n\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Warning)\n\t\t\t<< "Failed to set new gid: " << strerror(err);\n\t}\n\n\t'
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ' proxyWorker;\n\tint ret = proxyWorker.init(ipam, std::move(fd));\n\tif (ret < 0) {\n\t\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Error)\n\t\t\t<< "Failed to initialize proxy worker";\n\t\treturn ret;\n\t}\n\n\tLOG('
    yield str((undefined(name='proxy_worker_name') if l_0_proxy_worker_name is missing else l_0_proxy_worker_name))
    yield ', Debug) << "Proxy worker successfully initialized";\n\n\tproxyWorker.run();\n\n\tproxyWorker.cleanup();\n\n\treturn 0;\n}'

blocks = {}
debug_info = '5=68&11=71&25=73&26=75&45=77&47=79&48=82&49=86&53=90&56=92&61=94&68=96&75=98&78=102&83=105&84=109&85=113&88=117&89=119&90=123&92=128&93=131&95=134&96=137&97=139&98=143&101=147&104=150&107=153&110=156&113=158&114=160&116=162&122=169&129=171&133=173&135=175&137=177&141=179&142=183&162=191&163=197&166=199&171=203&175=205&176=207&178=209&182=215&201=217&208=219&214=221&227=223&231=225&234=227&239=229'