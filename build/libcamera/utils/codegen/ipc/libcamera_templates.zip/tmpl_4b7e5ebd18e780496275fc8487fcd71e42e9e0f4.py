from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'core_ipa_interface.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_has_map = resolve('has_map')
    l_0_has_string = resolve('has_string')
    l_0_has_array = resolve('has_array')
    l_0_consts = resolve('consts')
    l_0_enums_gen_header = resolve('enums_gen_header')
    l_0_structs_gen_header = resolve('structs_gen_header')
    l_0_funcs = missing
    try:
        t_1 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    pass
    l_0_funcs = context.vars['funcs'] = environment.get_template('definition_functions.tmpl', 'core_ipa_interface.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * libcamera core definitions for Image Processing Algorithms\n *\n * This file is auto-generated. Do not edit.\n */\n\n#pragma once\n\n'
    if (undefined(name='has_map') if l_0_has_map is missing else l_0_has_map):
        pass
        yield '#include <map>'
    yield '\n'
    if (undefined(name='has_string') if l_0_has_string is missing else l_0_has_string):
        pass
        yield '#include <string>'
    yield '\n'
    if (undefined(name='has_array') if l_0_has_array is missing else l_0_has_array):
        pass
        yield '#include <vector>'
    yield '\n\n#include <libcamera/controls.h>\n#include <libcamera/framebuffer.h>\n#include <libcamera/geometry.h>\n\n#include <libcamera/ipa/ipa_interface.h>\n\nnamespace libcamera {\n\n\n'
    for l_1_const in (undefined(name='consts') if l_0_consts is missing else l_0_consts):
        _loop_vars = {}
        pass
        yield '\nstatic const '
        yield str(t_1(environment.getattr(l_1_const, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_const, 'mojom_name'))
        yield ' = '
        yield str(environment.getattr(l_1_const, 'value'))
        yield ';\n'
    l_1_const = missing
    yield '\n\n'
    for l_1_enum in (undefined(name='enums_gen_header') if l_0_enums_gen_header is missing else l_0_enums_gen_header):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='funcs') if l_0_funcs is missing else l_0_funcs), 'define_enum'), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs_gen_header') if l_0_structs_gen_header is missing else l_0_structs_gen_header):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='funcs') if l_0_funcs is missing else l_0_funcs), 'define_struct'), l_1_struct, _loop_vars=_loop_vars))
        yield '\n'
    l_1_struct = missing
    yield '\n\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=24&17=27&18=31&19=35&30=39&31=43&34=51&35=55&38=58&39=62'