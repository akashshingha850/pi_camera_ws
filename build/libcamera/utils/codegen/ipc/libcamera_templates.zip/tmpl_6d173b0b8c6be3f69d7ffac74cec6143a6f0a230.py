from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_ipa_proxy.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_name = resolve('module_name')
    l_0_has_namespace = resolve('has_namespace')
    l_0_namespace = resolve('namespace')
    l_0_proxy_name = resolve('proxy_name')
    l_0_interface_name = resolve('interface_name')
    l_0_interface_main = resolve('interface_main')
    l_0_interface_event = resolve('interface_event')
    l_0_proxy_funcs = missing
    try:
        t_1 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_2 = environment.filters['is_async']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_async' found.")
    try:
        t_3 = environment.filters['method_param_outputs']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'method_param_outputs' found.")
    try:
        t_4 = environment.filters['method_return_value']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'method_return_value' found.")
    try:
        t_5 = environment.filters['params_comma_sep']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'params_comma_sep' found.")
    try:
        t_6 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    pass
    l_0_proxy_funcs = context.vars['proxy_funcs'] = environment.get_template('proxy_functions.tmpl', 'module_ipa_proxy.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('proxy_funcs')
    yield '/* SPDX-License-Identifier: LGPL-2.1-or-later */\n/*\n * Copyright (C) 2020, Google Inc.\n *\n * Image Processing Algorithm proxy for '
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '\n *\n * This file is auto-generated. Do not edit.\n */\n\n#pragma once\n\n#include <libcamera/ipa/ipa_interface.h>\n#include <libcamera/ipa/'
    yield str((undefined(name='module_name') if l_0_module_name is missing else l_0_module_name))
    yield '_ipa_interface.h>\n\n#include <libcamera/base/object.h>\n#include <libcamera/base/thread.h>\n\n#include "libcamera/internal/control_serializer.h"\n#include "libcamera/internal/ipa_proxy.h"\n#include "libcamera/internal/ipc_pipe.h"\n#include "libcamera/internal/ipc_pipe_unixsocket.h"\n#include "libcamera/internal/ipc_unixsocket.h"\n\nnamespace libcamera {'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in (undefined(name='namespace') if l_0_namespace is missing else l_0_namespace):
            _loop_vars = {}
            pass
            yield '\nnamespace '
            yield str(l_1_ns)
            yield ' {\n'
        l_1_ns = missing
    yield '\n\nclass '
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield ' : public IPAProxy, public '
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ', public Object\n{\npublic:\n\t'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(IPAModule *ipam, bool isolate);\n\t~'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '();\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, '', False, True, _loop_vars=_loop_vars), 8, True))
        yield ';\n'
    l_1_method = missing
    yield '\n\nprivate:\n\tvoid recvMessage(const IPCMessage &data);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'Thread', False, _loop_vars=_loop_vars), 8, True))
        yield ';\n'
        yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'IPC', False, _loop_vars=_loop_vars), 8, True))
        yield ';\n'
    l_1_method = missing
    yield '\n'
    for l_1_method in environment.getattr((undefined(name='interface_event') if l_0_interface_event is missing else l_0_interface_event), 'methods'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, 'Thread', False, _loop_vars=_loop_vars), 8, True))
        yield ';\n\tvoid '
        yield str(environment.getattr(l_1_method, 'mojom_name'))
        yield 'IPC(\n\t\tstd::vector<uint8_t>::const_iterator data,\n\t\tsize_t dataSize,\n\t\tconst std::vector<SharedFD> &fds);\n'
    l_1_method = missing
    yield '\n\n\t/* Helper class to invoke async functions in another thread. */\n\tclass ThreadProxy : public Object\n\t{\n\tpublic:\n\t\tThreadProxy()\n\t\t\t: ipa_(nullptr)\n\t\t{\n\t\t}\n\n\t\tvoid setIPA('
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *ipa)\n\t\t{\n\t\t\tipa_ = ipa;\n\t\t}\n\n\t\tvoid stop()\n\t\t{\n\t\t\tipa_->stop();\n\t\t}\n'
    for l_1_method in environment.getattr((undefined(name='interface_main') if l_0_interface_main is missing else l_0_interface_main), 'methods'):
        _loop_vars = {}
        pass
        if t_2(l_1_method):
            pass
            yield '\n\t\t'
            yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, '', False, _loop_vars=_loop_vars), 16))
            yield '\n\t\t{\n\t\t\tipa_->'
            yield str(environment.getattr(l_1_method, 'mojom_name'))
            yield '('
            yield str(t_5(environment.getattr(l_1_method, 'parameters')))
            yield ');\n\t\t}'
        elif (environment.getattr(l_1_method, 'mojom_name') == 'start'):
            pass
            yield '\n\t\t'
            yield str(t_1(context.call(environment.getattr((undefined(name='proxy_funcs') if l_0_proxy_funcs is missing else l_0_proxy_funcs), 'func_sig'), (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), l_1_method, '', False, _loop_vars=_loop_vars), 16))
            yield '\n\t\t{'
            if (t_4(l_1_method) != 'void'):
                pass
                yield '\n\t\t\treturn ipa_->'
                yield str(environment.getattr(l_1_method, 'mojom_name'))
                yield '('
                yield str(t_5(environment.getattr(l_1_method, 'parameters')))
                yield ');'
            else:
                pass
                yield '\n\t\t\tipa_->'
                yield str(environment.getattr(l_1_method, 'mojom_name'))
                yield '('
                yield str(t_5(environment.getattr(l_1_method, 'parameters')))
                yield str((', ' if t_5(t_3(l_1_method)) else cond_expr_undefined("the inline if-expression on line 93 in 'module_ipa_proxy.h.tmpl' evaluated to false and no else section was defined.")))
                yield str(t_5(t_3(l_1_method)))
                yield ');'
            yield '\n\t\t}'
    l_1_method = missing
    yield '\n\n\tprivate:\n\t\t'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield ' *ipa_;\n\t};\n\n\tThread thread_;\n\tThreadProxy proxy_;\n\tstd::unique_ptr<'
    yield str((undefined(name='interface_name') if l_0_interface_name is missing else l_0_interface_name))
    yield '> ipa_;\n\n\tconst bool isolate_;\n\n\tstd::unique_ptr<IPCPipeUnixSocket> ipc_;\n\n\tControlSerializer controlSerializer_;\n\n\n\tuint32_t seq_;\n};'
    if (undefined(name='has_namespace') if l_0_has_namespace is missing else l_0_has_namespace):
        pass
        yield '\n'
        for l_1_ns in t_6((undefined(name='namespace') if l_0_namespace is missing else l_0_namespace)):
            _loop_vars = {}
            pass
            yield '\n} /* namespace '
            yield str(l_1_ns)
            yield ' */\n'
        l_1_ns = missing
    yield '\n} /* namespace libcamera */'

blocks = {}
debug_info = '5=55&11=58&19=60&31=62&32=65&33=69&37=73&40=77&41=79&43=81&44=85&50=89&51=93&52=95&54=99&55=103&56=105&71=109&80=111&81=114&82=117&84=119&86=123&87=126&89=128&90=131&92=138&93=141&94=142&101=147&106=149&118=151&119=154&120=158'