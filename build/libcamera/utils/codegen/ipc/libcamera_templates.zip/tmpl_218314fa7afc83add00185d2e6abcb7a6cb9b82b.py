from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'definition_functions.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_define_enum = l_0_define_struct = missing
    try:
        t_1 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_2 = environment.filters['has_default_fields']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'has_default_fields' found.")
    try:
        t_3 = environment.filters['is_pod']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_pod' found.")
    try:
        t_4 = environment.filters['is_scoped']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_scoped' found.")
    try:
        t_5 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_6 = environment.filters['with_default_values']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'with_default_values' found.")
    pass
    def macro(l_1_enum):
        t_7 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_7.extend((
            'enum',
            str((' class' if t_4(l_1_enum) else cond_expr_undefined("the inline if-expression on line 12 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ' ',
            str(environment.getattr(l_1_enum, 'mojom_name')),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_7.extend((
                '\n\t',
                str(environment.getattr(l_2_field, 'mojom_name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        t_7.append(
            '\n};',
        )
        return concat(t_7)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_8 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_8.extend((
            'struct ',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '\n{\npublic:\n#ifndef __DOXYGEN__\n\t',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '()',
        ))
        if t_2(l_1_struct):
            pass
            t_8.append(
                '\n\t\t:',
            )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(t_6(environment.getattr(l_1_struct, 'fields')), undefined):
            _loop_vars = {}
            pass
            t_8.extend((
                str((' ' if environment.getattr(l_2_loop, 'first') else cond_expr_undefined("the inline if-expression on line 32 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
                str(environment.getattr(l_2_field, 'mojom_name')),
                '(',
                str(t_1(l_2_field)),
                ')',
                str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 32 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        t_8.extend((
            '\n\t{\n\t}\n\n\t',
            str(environment.getattr(l_1_struct, 'mojom_name')),
            '(',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_8.extend((
                str(('const ' if (not t_3(l_2_field)) else cond_expr_undefined("the inline if-expression on line 39 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
                str(t_5(l_2_field)),
                ' ',
                str(('&' if (not t_3(l_2_field)) else cond_expr_undefined("the inline if-expression on line 39 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
                '_',
                str(environment.getattr(l_2_field, 'mojom_name')),
                str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 39 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        t_8.append(
            ')\n\t\t:',
        )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_8.extend((
                str((' ' if environment.getattr(l_2_loop, 'first') else cond_expr_undefined("the inline if-expression on line 44 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
                str(environment.getattr(l_2_field, 'mojom_name')),
                '(_',
                str(environment.getattr(l_2_field, 'mojom_name')),
                ')',
                str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 44 in 'definition_functions.tmpl' evaluated to false and no else section was defined."))),
            ))
        l_2_loop = l_2_field = missing
        t_8.append(
            '\n\t{\n\t}\n#endif\n\n',
        )
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            _loop_vars = {}
            pass
            t_8.extend((
                '\n\t',
                str(t_5(l_2_field)),
                ' ',
                str(environment.getattr(l_2_field, 'mojom_name')),
                ';',
            ))
        l_2_field = missing
        t_8.append(
            '\n};',
        )
        return concat(t_8)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '11=48&12=55&13=60&14=65&24=77&25=84&29=86&31=95&32=99&37=109&38=113&39=117&43=130&44=134&50=145&51=150'